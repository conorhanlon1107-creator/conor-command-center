# ✦ Conor Command Center

A mobile-friendly, single-file personal dashboard for tracking housing leads, planned expenses, tasks, and follow-ups.

## Run it

Open `index.html` in a web browser. No installation or dependencies needed.

## Features

- Overview with live counts and today's focus
- Housing tracker, rent filter, application status, and notes
- Budget planner with expense categories and remaining unallocated estimate
- Task checklist and follow-up tracker
- Fun celebration button ✨
- Export and import JSON backups
- Responsive dark-mode interface

## Privacy

All data is stored in your browser's `localStorage`; it does **not** synchronize across devices and can be lost if browser data is cleared. Export backups regularly. **Do not commit your exported backup or personal data to a public GitHub repository.** The starter contains no personal records.

## Publish on GitHub

1. On GitHub select **New repository**, name it `conor-command-center`, and choose **Private** initially.
2. Upload `index.html`, `README.md`, and `.gitignore` to the repository.
3. Commit changes. For hosting with GitHub Pages, note that a Pages site may be publicly accessible even if the source repository is private, depending on plan/settings. Don't put personal data in repository files.
4. To run locally, download the repo and double-click `index.html`.

No live Gmail, calendar, banking, or automated email access is included. Those require additional authentication, backend infrastructure, and privacy safeguards.
